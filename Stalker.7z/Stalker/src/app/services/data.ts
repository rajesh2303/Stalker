export var  data=[{
    id:1,
    name:'Guna sekaran hospital',
    coordinates:[10.940484, 78.144199],
    phno:9080201170,
    popup:'Guna sekaran hospital',
    distance:0
},
{
    id:2,
    name:'Loganathan hospital',
    coordinates:[10.940090,78.145467],
    phno:9080201170,
    popup:'Loganathan hospital',
    distance:0
},
{
    id:3,
    name:'Madura Nursing Home',
    coordinates:[10.941158,78.142503],
    phno:4324250273,
    popup:'Madura Nursing Home',
    distance:0
},
{
    id:4,
    name:'sam clinic',
    coordinates:[10.940020,78.14070],
    phno:9443250889,
    popup:'sam clinic',
    distance:0
},
{
    id:5,
    name:'sakthivel clinic',
    coordinates:[10.940146,78.143920],
    phno:9080201170,
    popup:'sakthivel clinic',
    distance:0
},
{
    id:6,
    name:'D.S.K Hospital',
    coordinates:[11.102880113661078, 77.36933358264518],
    phno:4212422011,
    popup:'D.S.K Hospital',
    distance:0
},
{
    id:7,
    name:'AMC Super Speciality Hospital',
    coordinates:[11.096409469422388, 77.34902084213442],
    phno:8999777444,
    popup:'AMC Super Speciality Hospital',
    distance:0
},
{
    id:8,
    name:'Government Hospital',
    coordinates:[11.09750430444553, 77.34943491131898],
    phno:9080201170,
    popup:'Government Hospital',
    distance:0
},
{
    id:9,
    name:'Banu Hospital',
    coordinates:[11.086512725353915, 77.34585036784365],
    phno:4212213677,
    popup:'Banu Hospital',
    distance:0
},
{
    id:10,
    name:'Meghna medical centre',
    coordinates:[11.087159028215272, 77.34826822074737],
    phno:9364124022,
    popup:'Meghna medical centre',
    distance:0
},
{
    id:11,
    name:'Sundaram Nursing Home',
    coordinates:[11.100081104480445, 77.35556066782304],
    phno:7871669999,
    popup:'Sundaram Nursing Home',
    distance:0
},
{
    id:12,
    name:'Revathi Medical Centre',
    coordinates:[11.100375891825042, 77.34987438464351],
    phno:9080201170,
    popup:'Revathi Medical Centre',
    distance:0
},
{
    id:13,
    name:'TMF Hospital',
    coordinates:[11.109264647455454, 77.34500319366518],
    phno:4212203657,
    popup:'TMFHospital',
    distance:0
},
{
    id:14,
    name:'OMS Hospital',
    coordinates:[11.068368504254586, 77.33970664121652],
    phno:4214246444,
    popup:'OMS Hospital',
    distance:0
},
{
    id:15,
    name:'PSG Hospitals',
    coordinates:[10.974060949208786, 77.18938039662004],
    phno:4255264100,
    popup:'PSG Hospitals',
    distance:0
},
{
    id:16,
    name:'Air Force Hospital',
    coordinates:[11.025438198745931, 77.16223863850648],
    phno:9080201170,
    popup:'Air Force Hospital',
    distance:0
},
{
    id:17,
    name:'KMCH Sulur Hospital',
    coordinates:[11.028586561258944, 77.1340169895331],
    phno:4222228222,
    popup:'KMCH Sulur Hospital',
},
{
    id:18,
    name:'Government Hospital Palladam',
    coordinates:[10.996436429139935, 77.28051425621996],
    phno:4255254007,
    popup:'Government Hospital Palladam',
    distance:0
},
{
    id:19,
    name:'Bala Ortho Hospital',
    coordinates:[11.08368866283911, 77.36852080098778],
    phno:4214322226,
    popup:'Bala Ortho Hospital',
    distance:0
},
{
    id:20,
    name:'Life guard Hospital',
    coordinates:[11.079491888582051, 77.34230790099633],
    phno:9487051010,
    popup:'Life guard Hospital',
    distance:0
},
{
    id:21,
    name:'Kritiga Hospital',
    coordinates:[11.096469520092525, 77.33758351995678],
    phno:4212246466,
    popup:'Kartiga Hospital',
    distance:0
},
{
    id:22,
    name:'Government Hospital Avinashi',
    coordinates:[11.194675640807626, 77.26865240227416],
    phno:4296272082,
    popup:'Government Hospital Avinashi',
    distance:0
},
{
    id:23,
    name:'Assumption Hospital',
    coordinates:[11.197412006547973, 77.26656386715362],
    phno:4296273367,
    popup:'Assumption Hospital',
    distance:0
},
{
    id:24,
    name:'Gokulam Baby Hospital',
    coordinates:[11.189154324464099, 77.27032514001462],
    phno:4296292064,
    popup:'Gokulam Baby Hospital',
    distance:0
},
{
    id:25,
    name:'venkateswara hospitals',
    coordinates:[9.166153465944868, 77.85109972535341],
    phno:9442648552,
    popup:"venkateswara hospitals",
    distance:0
},
{
    id:26,
    name:'aarthi hospitals',
    coordinates:[9.17508090679731, 77.86639397298772],
    phno:4632221346,
    popup:'aarthi hospitals',
    distance:0
},
{
    id:27,
    name:'sri hospitals',
    coordinates:[9.173852648065578, 77.87416247959774],
    phno:4632234000,
    popup:'sri hospitals',
    distance:0
},
{
    id:28,
    name:'dhyan hospitals',
    coordinates:[9.168190619915027, 77.87273623033731],
    phno:8300109666,
    popup:'dhyan hospitals',
    distance:0
},
{
    id:29,
    name:'jai hospitals',
    coordinates:[9.164451332948461, 77.84782616040674],
    phno:4632234199,
    popup:'jai hospitals',
    distance:0
},
{
    id:30,
    name:'kamala hospitals',
    coordinates:[9.173124040342296, 77.87137396093809],
    phno:4632222077,
    popup:'kamala hospitals',
    distance:0
},
{
    id:31,
    name:'venkateswara hospitals',
    coordinates:[9.166153465944868, 77.85109972535341],
    phno:9442648552,
    popup:"venkateswara hospitals",
    distance:0
},
{
    id:32,
    name:'aarthi hospitals',
    coordinates:[9.17508090679731, 77.86639397298772],
    phno:4632221346,
    popup:'aarthi hospitals',
    distance:0
},
{
    id:33,
    name:'KMCH',
    coordinates:[11.047329594384589, 77.03978024202536],
    phno:4224323800,
    popup:'KMCH',
    distance:0
},
{
    id:34,
    name:'HARINISHRAVAN HOSPITALS',
    coordinates:[11.07359286388747, 77.00025464983621],
    phno:4226566770,
    popup:'harinishravan hospitals',
    distance:0
},
{
    id:35,
    name:'karpagam hospitals',
    coordinates:[10.885656808649433, 77.0075887026134],
    phno:4222904453,
    popup:'karpagam hospitals',
    distance:0
},
{
    id:36,
    name:'karpagam hospital rural',
    coordinates:[10.882732434195354, 77.05923063092098],
    phno:4222611144,
    popup:'karpagam hospital rural',
    distance:0
},
{
    id:37,
    name:'kumaran medical clinic',
    coordinates:[10.897682446069082, 77.01492431664953],
    phno:+919677829074,
    popup:'kumaran clinic',
    distance:0
},
{
    id:38,
    name:'sri venkateshwara hospitals',
    coordinates:[10.832070438845905, 77.02003952116966],
    phno:4259242331,
    popup:'sri venkateshwara hospitals',
    distance:0
},
{
    id:39,
    name:'csr hospitals',
    coordinates:[11.021295495900226, 76.96614230932994],
    phno:4222524762,
    popup:'csr hospitals',
    distance:0
},
{
    id:40,
    name:'kongunadu hospitals',
    coordinates:[11.018991651286708, 76.96226140292318],
    phno:+917358841555,
    popup:'kongunadu hospitals',
    distance:0
},
{
    id:41,
    name:'sheela hospitals',
    coordinates:[11.018499213519277, 76.96047691658218],
    phno:4224334500,
    popup:'sheela hospitals',
    distance:0
},
{
    id:42,
    name:'GKNM',
    coordinates:[11.013517106722695, 76.98121741670151],
    phno:4222245000,
    popup:'GKNM',
    distance:0
},
{
    id:43,
    name:'Sri Ramakrishna hospitals',
    coordinates:[11.023701385149115, 76.9780821885909],
    phno:4222245000,
    popup:'ramakrishna hospitals',
    distance:0
},
{
    id:44,
    name:'one care hospitals',
    coordinates:[11.027049546631947, 76.94866981475971],
    phno:4222431010,
    popup:'one care hospitals',
    distance:0
},
{
    id:45,
    name:'PSG hospitals',
    coordinates:[11.027049546631947, 76.94866981475971],
    phno:4222570170,
    popup:'PSG hospitals',
    distance:0
}
]
export var contact=[];
export var env={
    latlon:[],
    iot:null
  }