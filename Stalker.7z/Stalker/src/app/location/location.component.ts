import { Component, OnInit } from '@angular/core';
import { latLng, tileLayer, Icon, icon, Marker,MapOptions } from "leaflet";
import {AngularFireDatabase} from '@angular/fire/database';
import * as Leaflet from 'leaflet';
import "leaflet";
import "leaflet-routing-machine";
declare let L;

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.scss']
})
export class LocationComponent implements OnInit {

  public remove;
	status=false;
	iotlat;
	iotlon;
	livelat;
	livelon;
	jsondata;
	map1: Leaflet.Map;
	constructor(public afd:AngularFireDatabase) {
	  }
	
	// // Override default Icons
	private defaultIcon: Icon = icon({
		iconUrl: "assets/images/marker-icon.png",
		shadowUrl: "assets/images/marker-shadow.png"
	});
	setView(lat,lan){
	this.map1 = Leaflet.map('map1').setView([lat,lan], 13);
	Leaflet.tileLayer( 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
 	 }).addTo(this.map1);
	}
	ngOnInit() {
	//console.log(this.status);
	Marker.prototype.options.icon = this.defaultIcon;
	this.afd.list('/location/').valueChanges().subscribe((data1)=>{
		this.iotlat=data1[0];
		this.iotlon=data1[1];
		this.status=false;
		this.setView(this.iotlat,this.iotlon);
		//console.log("in fire",this.status)
    	setInterval(() => {
			this.map1.invalidateSize();
		  }, 100);
		this.getlive();
	})
	}
	getlive(){
		navigator.geolocation.getCurrentPosition(resp => {
			if(this.status==false){
			this.status=true;
			this.livelat=resp.coords.latitude;
			this.livelon=resp.coords.longitude;
			this.routedata();
			}
		});

	}
	routedata(){
		//console.log("in rout",this.status)
		L.Routing.control({
			waypoints: [
			L.latLng(this.livelat,this.livelon),
			L.latLng(this.iotlat,this.iotlon)
			]
		}).addTo(this.map1);
		this.map1.setView([this.livelat,this.livelon],10);
	}
	
}
