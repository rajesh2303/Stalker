import { Component, OnInit } from '@angular/core';
import {latLng, MapOptions, tileLayer, Map, Marker, icon} from 'leaflet';
import * as Leaflet from 'leaflet';
import {data} from '../services/data';
import {AngularFireDatabase} from '@angular/fire/database';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(public afd:AngularFireDatabase) {
    }
	mapOptions: MapOptions;
	status:boolean=true;
  	button:string="IOT";
	public locationarray=[];
  	mobilelat:any;
  	mobilelon:any;
	nearby=[];
  	title = 'Stalker';
	map: Leaflet.Map;
	  ngOnInit(){
		
		  this.setview();
		  //sessionStorage.setItem("iot", "false");
		  if(this.status==true){
			sessionStorage.setItem("iot", "true");
		  this.getDataIOT();}
		  else{
			sessionStorage.setItem("iot", "false");
			this.watchposition();}
	}
	setview(){
		this.map = Leaflet.map('map').setView([10.9601, 78.0766], 13);
		Leaflet.tileLayer( 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
		}).addTo(this.map);
		  var leaf=Leaflet.icon({
			  iconUrl:"assets/images/hospital-sign.png",
			  iconSize:[20,20],
			  iconAnchor:[22,94],
			  popupAnchor:[-3,-76]
		  });
		  data.forEach((e)=>{
		  Leaflet.marker([e.coordinates[0], e.coordinates[1]],{icon:leaf}).addTo(this.map).bindPopup(e.name).openPopup();
		});
	  }
	  public remove;
	  getDataIOT(){
		var personlatitude;
		var personlongitude;
		 this.afd.list('/location/').valueChanges().subscribe((data1)=>{
		  data1.forEach((ele)=>{
			personlatitude=this.mobilelat=data1[0];
			personlongitude=this.mobilelon=data1[1];
		  });
		  sessionStorage.setItem("iotlatitude",personlatitude);
		  sessionStorage.setItem("iotlongitude",personlongitude);
		  //console.log(data1,personlatitude,personlongitude);
		  var leaf=Leaflet.icon({
			iconUrl:"assets/images/marker-icon.png",
			iconSize:[37,40],
			iconAnchor:[22,94],
			popupAnchor:[-3,-76]
			});
		  if(this.remove!=undefined){
			this.map.removeLayer(this.remove)
			}
		  this.map.setView([personlatitude, personlongitude],14);
		  var remove= Leaflet.marker([personlatitude, personlongitude],{icon:leaf}).addTo(this.map).bindPopup("person").openPopup();
		  this.nearbyhospital(personlatitude, personlongitude);
		  this.remove=remove;
		});
		}

		nearbyhospital(personlatitude, personlongitude){
			// sessionStorage.setItem("latlon", "${personlatitude}, ${personlongitude}");
			// sessionStorage.setItem("iot", "true");
			function closestLocation(targetLocation, locationData) {
			  function vectorDistance(dx, dy) {
				  return Math.sqrt(dx * dx + dy * dy);
			  }
		  
			  function locationDistance(location1, location2) {
				  var dx = location1.latitude - location2.coordinates[0],
					  dy = location1.longitude - location2.coordinates[1];
		  
				  return vectorDistance(dx, dy);
			  }
		  
			  return locationData.reduce((prev, curr) =>{
				  var prevDistance = locationDistance(targetLocation , prev),
					  currDistance = locationDistance(targetLocation , curr);
				  return (prevDistance < currDistance) ? prev : curr;
			  });
		  }
			 var targetLocation ={
				  latitude: personlatitude,  
				  longitude: personlongitude
			  }
			  var closest = closestLocation(targetLocation, data);
			  this.distance(this.mobilelat,this.mobilelon,closest.coordinates[0],closest.coordinates[1],closest);
		   }
		   distance(lat1, lon1, lat2, lon2,obj){
			var p = 0.017453292519943295;    
			var c = Math.cos;
			var a = 0.5 - c((lat2 - lat1) * p)/2 + 
					c(lat1 * p) * c(lat2 * p) * 
					(1 - c((lon2 - lon1) * p))/2;
			this.nearby=[obj.name,obj.phno,12742 * Math.asin(Math.sqrt(a))]
		  }
		  jsondata
		  watchposition(){
			navigator.geolocation.getCurrentPosition(resp => {
					  if(this.status==false){
					  this.mobilelat=resp.coords.latitude;
					  this.mobilelon=resp.coords.longitude;
					  this.button="LIVE";
					  this.getDataLive(resp.coords.latitude,resp.coords.longitude);}
				console.log({lng: resp.coords.longitude, lat: resp.coords.latitude});
			  },
			  err => {
				console.log(err);
			  });
			}
getDataLive(lat,lon){
	var leaf=Leaflet.icon({
	iconUrl:"assets/images/marker-icon.png",
	iconSize:[37,40],
	iconAnchor:[22,94],
	popupAnchor:[-3,-76]
	});
	if(this.remove!=undefined){
		this.map.removeLayer(this.remove);
		}
	this.map.setView([lat, lon],14);
	var remove= Leaflet.marker([lat, lon],{icon:leaf}).addTo(this.map).bindPopup("person").openPopup();
	this.nearbyhospital(lat, lon);
	this.remove=remove;
	}		 
btn(){
	this.status=!this.status;
	if(this.status==false){
	  sessionStorage.setItem("iot", "false");
	  this.watchposition();
	}
	else{
		sessionStorage.setItem("iot", "true");
	  this.getDataIOT();
	  this.button="IOT";
	}
  }


}
