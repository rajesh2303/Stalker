import { Component, OnInit } from '@angular/core';
import * as Leaflet from 'leaflet';
import { latLng, tileLayer, Icon, icon, Marker,MapOptions } from "leaflet";
import "leaflet";
import "leaflet-routing-machine";
declare let L;
import {data} from '../services/data';

@Component({
  selector: 'app-hospital',
  templateUrl: './hospital.component.html',
  styleUrls: ['./hospital.component.scss']
})
export class HospitalComponent implements OnInit {
  map2: Leaflet.Map;
  mapOptions: MapOptions;
  latitude:any;
  longitude:any;
  data1=data;
  status:boolean=true;
  jsondata:any;
  routlat:any;
  routlan:any;
  constructor() { }
  private defaultIcon: Icon = icon({
    iconUrl: "assets/images/marker-icon.png",
    shadowUrl: "assets/images/marker-shadow.png"
  });
  

  ngOnInit(): void {
    console.log("HI")
    Marker.prototype.options.icon = this.defaultIcon;
    if( sessionStorage.getItem("iot") =="true"){
    this.latitude=this.routlat=sessionStorage.getItem("iotlatitude");
    this.longitude=this.routlan=sessionStorage.getItem("iotlongitude");
    this.data1.forEach(e=>{
      e.distance=this.distance(this.latitude,this.longitude,e.coordinates[0],e.coordinates[1]);
    });
    this.data1.sort((a, b)=>{
      return a.distance - b.distance;
    });}
    else{
      navigator.geolocation.getCurrentPosition(resp => {
        this.latitude=this.routlat=resp.coords.latitude;
        this.longitude=this.routlan=resp.coords.longitude;
        console.log(this.latitude,this.longitude);
        this.data1.forEach(e=>{
          e.distance=this.distance(this.latitude,this.longitude,e.coordinates[0],e.coordinates[1]);
        });
        this.data1.sort((a, b)=>{
          return a.distance - b.distance;
        });
      },
      err => {
      console.log(err);
      });
      }
      this.setview();
      setInterval(() => {
        this.map2.invalidateSize();
        }, 100);
  }
  setview(){
    this.map2 = Leaflet.map('map2').setView([10.9601, 78.0766], 13);
  Leaflet.tileLayer( 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
}).addTo(this.map2);
var leaf=Leaflet.icon({
  iconUrl:"assets/images/hospital-sign.png",
  iconSize:[20,20],
  iconAnchor:[22,94],
  popupAnchor:[-3,-76]
});
data.forEach((e)=>{
Leaflet.marker([e.coordinates[0], e.coordinates[1]],{icon:leaf}).addTo(this.map2).bindPopup(e.name).openPopup();
});
  }
  distance(lat1, lon1, lat2, lon2){
    var p = 0.017453292519943295;    
    var c = Math.cos;
    var a = 0.5 - c((lat2 - lat1) * p)/2 + 
            c(lat1 * p) * c(lat2 * p) * 
            (1 - c((lon2 - lon1) * p))/2;
    return 12742 * Math.asin(Math.sqrt(a))
  }
  gps(rou){
    this.status=false;
    console.log(rou);
    L.Routing.control({
			waypoints: [
			L.latLng(this.routlat,this.routlan),
			L.latLng(rou.coordinates[0],rou.coordinates[1])
			]
		}).addTo(this.map2);
		this.map2.setView([this.routlat,this.routlat],12);
    
  }

}
