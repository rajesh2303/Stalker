import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {LeafletModule} from '@asymmetrik/ngx-leaflet';
import {MatCardModule} from '@angular/material/card';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatChipsModule} from '@angular/material/chips';
import {MatIconModule} from '@angular/material/icon';
import { AngularFireModule } from '@angular/fire';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import {ServicesService} from './services/services.service';

import {HttpClientModule} from '@angular/common/http';
import { HospitalComponent } from './hospital/hospital.component';
import { LocationComponent } from './location/location.component';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
var Config = {
  apiKey: "AIzaSyCrFaL7cYy2JYfIHJ8w6UdX1VUpBTl5JE0",
  authDomain: "hpfirebaseproject-4148e.firebaseapp.com",
  databaseURL: "https://hpfirebaseproject-4148e.firebaseio.com",
  projectId: "hpfirebaseproject-4148e",
  storageBucket: "hpfirebaseproject-4148e.appspot.com",
  messagingSenderId: "807514355709",
  appId: "1:807514355709:web:75258e3f6b8d3705f44b94"
};

@NgModule({
  declarations: [
    AppComponent,
    HospitalComponent,
    LocationComponent,
    HomeComponent,
    AboutusComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatCardModule,
    LeafletModule,
    MatGridListModule,
    MatChipsModule,
    MatIconModule,
    AngularFireDatabaseModule,
    AngularFireModule,
    AngularFireModule.initializeApp(Config),
    HttpClientModule
    
  ],
  providers: [
    ServicesService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
